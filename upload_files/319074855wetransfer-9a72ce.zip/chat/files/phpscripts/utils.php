<?php
	function check_common_val($row1, $row2, $value) {
		
	}
?>
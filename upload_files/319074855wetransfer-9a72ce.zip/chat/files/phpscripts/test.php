<?php
echo "fuck";

?>
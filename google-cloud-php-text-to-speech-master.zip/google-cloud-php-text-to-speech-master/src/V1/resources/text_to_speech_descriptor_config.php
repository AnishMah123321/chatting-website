<?php

return [
    'interfaces' => [
        'google.cloud.texttospeech.v1.TextToSpeech' => [
        ],
    ],
];
